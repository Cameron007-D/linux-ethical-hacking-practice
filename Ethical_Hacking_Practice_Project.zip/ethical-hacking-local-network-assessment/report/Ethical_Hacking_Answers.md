# Ethical Hacking Practice: Local Network Assessment

**Status:** Preliminary report — Nessus results still required  
**Environment:** Authorized local/training network  
**Assessment date:** Not confirmed from the supplied screenshots

## Purpose and authorization

The purpose of this exercise is to map an authorized local network, identify exposed services, and assess discovered hosts for vulnerabilities. Testing must be limited to systems owned by the learner or explicitly authorized for assessment. Private network identifiers are omitted from this public report.

## 1. Network topology and service discovery

### 1a. Tool selection

**Nmap** is appropriate for host discovery, port scanning, and service/version detection.

### 1b. Scan observations

The provided Nmap host-discovery screenshot reports **3 hosts up** in the scanned range. The PDF also includes a service-scan screenshot for a host. Its terminal text is too small to verify the complete list of open ports, services, and versions accurately, so those details are not reproduced as facts here.

| Item | Observation |
| --- | --- |
| Active hosts | 3 hosts reported up by the shown Nmap discovery scan |
| Open ports/services | A service scan is shown; exact entries need confirmation from readable output |
| Network identifiers | Redacted/omitted from this public version |

### 1c. Evidence

The source PDF includes Nmap screenshots. Before adding screenshots to this repository, use original captures from the actual scan and redact identifiers such as private IP addresses, MAC addresses, and hostnames if they should not be public. Do not substitute course sample output for personal scan evidence.

## 2. Vulnerability assessment

### 2a. Tool selection

**Nessus** is the vulnerability-scanning tool identified by the course instructions.

### 2b. Scan evidence supplied

The Nessus image provided with the course page is explicitly captioned as a **sample screenshot of a basic scan of a local network**. It illustrates how a Nessus results dashboard may display host findings and severity categories. It is not evidence of a completed scan on this assessment's network, so it is not used to report findings.

### 2c. Findings and severity totals

The supplied files do not include readable results from an actual Nessus scan of the assessed hosts. The number of vulnerabilities in each severity category is therefore **not available**. No critical, high, medium, or low counts can be responsibly claimed from the sample image.

| Severity | Count |
| --- | --- |
| Critical | Not available — actual Nessus results required |
| High | Not available — actual Nessus results required |
| Medium | Not available — actual Nessus results required |
| Low | Not available — actual Nessus results required |

Severity should be taken from the completed scan's results summary, with individual findings opened and reviewed to confirm affected hosts and evidence.

## Metasploit research shown in the source PDF

The PDF includes Metasploit searches for backdoor-related modules and an HTTP version-check module. These screenshots document research activity only. They do not demonstrate a successful exploit, establish that a scanned host is vulnerable, or replace the required Nessus scan.

## Conclusion and next actions

The available evidence supports a preliminary Nmap discovery result of three active hosts and shows further service scanning and Metasploit research. A complete vulnerability assessment still requires readable Nmap service results and an actual Nessus scan of the authorized systems. Once those are available, add the verified service inventory, severity totals, affected findings, evidence, and recommended remediation.

## Public-release privacy check

Before publication, review every screenshot and report for private IPs, MAC addresses, public IP addresses, device names, usernames, credentials, tokens, and personal information. Keep raw Nessus exports and other sensitive scan data private unless specifically required by the assessor.
