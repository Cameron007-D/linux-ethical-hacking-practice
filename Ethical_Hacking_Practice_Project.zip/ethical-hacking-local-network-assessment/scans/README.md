# Sanitized scan output

Add only scan output you collected from systems you own or are authorized to assess. Prefer a sanitized Nmap text export with the target identifiers reviewed for privacy. Keep original `.nessus` exports and raw reports private unless your assessor requires them.
