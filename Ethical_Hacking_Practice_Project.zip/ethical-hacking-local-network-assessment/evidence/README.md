# Evidence to add

Replace this note with screenshots captured from your own authorized assessment:

1. Nmap host-discovery output showing the scan scope and active-host count.
2. Nmap service-scan output showing open ports, service names, and versions.
3. Nessus completed-scan summary showing the finding severities.

The supplied course screenshots show examples and instructions. Keep them as learning references; do not present them as evidence of your own network results. Redact private identifiers before committing evidence to a public repository.
